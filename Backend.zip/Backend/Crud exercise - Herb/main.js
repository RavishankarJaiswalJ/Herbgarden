const express = require("express")
const app=express();
const { append } = require('express/lib/response');
const mongoose = require('mongoose');
const dbURL = "mongodb://127.0.0.1:27017/products";
const products = require('./models/products');
const crudController = require("./controllers/crudcontroller");
const UserController = require("./controllers/usercontroller");
const checkAuth=require("./middleware/check-auth")
const req = require("express/lib/request");
const cors = require("cors");
var corsOptions = {
  origin: "http://localhost:4200"
};
app.use(cors(corsOptions));
mongoose.Promise=global.Promise;
//Set up the connection the database
mongoose.connect(dbURL,{useNewUrlParser:true,useUnifiedTopology:true});
//assign the database to a variable 
const db = mongoose.connection;
module.exports=db;
//const express = require('express');
const port =process.env.PORT||3000;

//app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.get('/',(req,res)=>{
    res.send("Welcome to Node API application");
});
app.get('/api/products', crudController.getAllProduct);
app.get('/api/products/:id',crudController.getProductById);
app.post('/api/products',checkAuth,crudController.createProduct);
app.delete('/api/products/:id',checkAuth,crudController.deleteProduct);
app.patch('/api/products/:id',checkAuth,crudController.updateProduct);

//UserController url
app.post(`/api/signup`,UserController.signup);
app.post(`/api/login`,UserController.login);

app.listen(port,()=>{console.log(`Running on port ${port}`)});