const express=require('express');
const router=express.Router();
const multer=require('multer');

const storage =multer.diskStorage({
    destination:(req,file,cb)=>{
        cb(null,"downloads/images")    },

})