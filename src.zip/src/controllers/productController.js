const Product=require('../productModel');
exports.getAllProducts=(req,res)=>{
    Product.find({}).exec().then((productData) => {
            res.status(200);
            res.send(productData);
    })
    .catch((error)=>{
        console.log(error.message);
        res.status(204);
        res.send("Invalid ID/ ID doesn't exists- Information",+error.message);
    })
    .then(()=>console.log("promise complete"));
}
exports.getProductById=(req,res)=>{
    pId=req.params.productId;
    // Product.findOne(req.params.productId).exec().then((productData) => {
    //         res.send(productData);
    // })
    // .catch((error)=>{
    //     console.log(error.message);return[];
    // })
    // .then(()=>console.log("promise complete for by ID"));
    Product.findOne({id: {$gte:pId} }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            res.send(docs);
        }
    });
}
exports.updateProductStatus=(req,res)=>{
    pId=req.params.productId;
    Product.findOne({id: {$gte:pId} },(err,product)=>{
        if(err){return res.send(err);}
        product.productName=req.body.productName;
        product.productCode=req.body.productCode;
        product.description=req.body.description;
        product.price=req.body.price;
        product.releaseDate=req.body.releaseDate;
        product.imageUrl=req.body.imageUrl;
        product.starRating=req.body.starRating;
        product.save();
        console.log(product);
        return res.json(product);
    });
}
exports.partialUpdate=(req,res)=>{
    pId=req.params.productId;
    Product.findOneAndUpdate({id: {$gte:pId} }, req.body).exec().then(data=>{
        if (!data) {
                return res.status(404).send();
            }
        res.send(data);
    })
    .catch((error)=>{
        console.log(error.message);
        res.status(204);
        res.send("Invalid ID/Id doesn't exists - Information :"+error.message);
    })
    .then(()=> console.log("promise completed for update"));
}
exports.deleteProduct=(req,res)=>{
    let id=req.params.productId;
    Product.deleteOne({_id:id}).exec().then(data=>{
        res.send(data)
    })
    .catch((error)=>{
        console.log(error.message);
        res.status(204);
        res.send("Invalid ID/Id doesn't exists - Information :"+error.message);
    })
    .then(()=> console.log("promise completed for delete"));
}
module.exports.createProduct=(req,res)=>{
    let product=req.body;
    Product.create(product).then(data=>{
        res.status(201);
        res.send(data)
    })

    .catch((error)=>{
        console.log(error.message);
        res.status(204);
        res.send("Invalid ID/Id doesn't exists - Information :"+error.message);
    })
    .then(()=> console.log("promise completed for create"));
}

