exports.respondWithWelcome=(req,res)=>{
    res.send({name:"index",value:"Welcome to Herb garden application"});
}