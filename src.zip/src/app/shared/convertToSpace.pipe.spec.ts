import { ConvertToSpacesPipe } from "./convert-to-spaces.pipes"

xdescribe('ConvertToSpacePipe',()=>{
    it('should convert the character to space',()=>{
        let pipe = new ConvertToSpacesPipe(); //arrange
        let res = pipe.transform('HBM-MNT','-');
        expect(res).toBe('HBM-MNT') //assert
    })
})