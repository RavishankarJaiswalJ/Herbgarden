import { Component, OnDestroy, OnInit } from "@angular/core";
import {  from, interval, merge, of, pipe, range } from "rxjs";
import { distinct, filter, map, mergeMap, take } from "rxjs/operators";

@Component({
    selector:'app-rxjs',
    template:`<h1> From Rxjs Demo </h1>`
})
export class RxjsComponent implements OnInit , OnDestroy{
    
    ngOnInit(): void {
      
        // const rangeAlpha$=from(range(97,26));
        // const obs=rangeAlpha$.pipe(map (val => [Math.abs(96-val),String.fromCharCode(val)]) );
        // obs.subscribe( val => 
        //  console.log(String(val[0]) + String(val[1])));
     
        // const numbers=interval(1000).pipe(take(6));
        // const arr = ['A','B','C','D','E','F'];
        // const alpha = interval(1010).pipe(map(x => arr[x] ));

        // const output$ = merge(alpha,numbers);
        // output$.subscribe(x => console.log(x));

        // const numbers=interval(10).pipe(take(100)).pipe(filter(x=> x%5 == 0));
        // numbers.subscribe(x => console.log(x));

        // const alpha = of('A','B','C','D','E','F').pipe(mergeMap((x=>range(1,6).pipe(map(i => x+i)))));
        // alpha.subscribe(x=> console.log(x));

        // var source = from([42,24,42,24]).pipe(distinct());

        // var subscription = source.subscribe(
        //     function (x) { console.log('Next :' + x.toString());},
        //     function (err) { console.log('Error :' + err);},
        //     function () { console.log("Completed")}
        // )



    } //end of OnInIt
    ngOnDestroy():void{
        console.log("From on Destroy");
        
    }
}

