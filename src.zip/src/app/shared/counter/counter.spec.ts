import { Counter } from "./counter"

describe("Counter",()=>{
    let cnt:any=null;
beforeEach(()=> cnt =new Counter()); //Instantiates Counter object inside beforeEach

it("should increment the counter by 1",()=>{
let cnt=new Counter(); //arrange
cnt.increment(); //act
expect(cnt.counter).toBe(1) //assert
});// end of increment spec

//To test decrement
it("should decrement the counter by 1",()=>{
    let cnt=new Counter(); //arrange
    cnt.decrement(); //act
    expect(cnt.counter).toBe(-1) //assert
})

}) //end of suite