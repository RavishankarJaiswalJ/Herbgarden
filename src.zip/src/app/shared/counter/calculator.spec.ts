import { Calculator } from "./calculator";


describe("Calculator",()=>{
    let res:any=null;
    let x=2;
    let y=3;

beforeEach(()=> res =new Calculator()); //Instantiates Counter object inside beforeEach

it("should add x and y",()=>{
let res=new Calculator(); //arrange

let ans = res.add(x,y); //act
expect(ans).toBe(5) //assert
});// end of increment spec

//To test decrement
it("should multiply  a and y",()=>{
    let cnt=new Calculator(); //arrange
    let ans1 = res.multiply(x,y); //act
    expect(ans1).toBe(6) //assert
})

}) //end of suite


