import { Component } from "@angular/core";


@Component({
    template: `<h1 class='bg-danger'> The page you are looking is not found </h1>`
})


export class ErrorPageComponent{

}