import { Component, OnDestroy, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { AuthService } from "src/app/auth/auth.service";


@Component({
    selector: 'app-nav',
    templateUrl: './navigation.component.html',
  })
  

export class NavigationComponent implements OnInit,OnDestroy {
  userIsAuthenticated=false;
 private authListenerSub$:any;

    constructor(private AuthService:AuthService){}

    ngOnInit(): void {
      this.userIsAuthenticated=this.AuthService.getIsAuthenticated();
      this.authListenerSub$ = this.AuthService.getAuthStatusListener().subscribe(isAuthenticated =>{
        this.userIsAuthenticated =isAuthenticated;
      });

    }

    //logout
    onLogout(){
      this.AuthService.logout();

    }

    ngOnDestroy(): void {
      this.authListenerSub$.unsubscribe();
    }
}