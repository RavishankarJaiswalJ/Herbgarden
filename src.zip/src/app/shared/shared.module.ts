import { NgModule } from '@angular/core';
import { StarComponent } from './star/star.component';
import { ConvertToSpacesPipe } from './convert-to-spaces.pipes';
import { CommonModule } from '@angular/common';
import { RxjsComponent } from './rxjsdemo';
import { GalleryComponent } from './gallery/gallery.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    StarComponent,
    GalleryComponent,
    RxjsComponent,
    ConvertToSpacesPipe,
  ],
  imports: [
    CommonModule,
    FormsModule,
  ],
  exports:[
    CommonModule,
    StarComponent,
    FormsModule,
    ConvertToSpacesPipe
  ]
})
export class SharedModule { }
