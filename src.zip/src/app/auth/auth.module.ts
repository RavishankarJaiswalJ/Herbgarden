import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { Signupcomponent } from './signup/signup.component';
import { AuthInterceptor } from './auth-interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

const userRoutes: Routes = [
  { path : 'signup',component: Signupcomponent},
   { path : 'login',component: LoginComponent}

];

@NgModule({
  declarations: [
    LoginComponent,
    Signupcomponent
  ],
  // providers:[{provide:HTTP_INTERCEPTORS,useClass:AuthInterceptor,multi:true}],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(userRoutes)
  ]
})
export class AuthModule { }
