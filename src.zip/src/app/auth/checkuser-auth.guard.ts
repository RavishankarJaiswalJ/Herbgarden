import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from "rxjs";
import { JwtHelperService } from "@auth0/angular-jwt";
import { Injectable } from "@angular/core";
import { AuthService } from "./auth.service";

@Injectable({
    providedIn:'root'
})
export class checkUserAuthGuard implements CanActivate{
constructor(private  authService:AuthService,private router:Router, private jwtHelperService:JwtHelperService){}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) :boolean {
        
        let token;
        let email=null;
        //Check  if user is Authenticated
        
        if(this.authService.getIsAuthenticated()){
            token =sessionStorage.getItem('token');
//if token alreaady exists for a user ,retrieve the email(required) iformation    
            if(token){
                token=JSON.stringify(sessionStorage.getItem('token'));
                email= this.jwtHelperService.decodeToken(token).email;
                console.log("Email:",email)
            }

        }//end of if for Authentication and decoding the token 
if(this.authService.getIsAuthenticated() && email== route.data['userName'])        
        {
        return true;
    }
    else{
        this.router.navigate(['/login'])
        return false;
    }
}// end of CanActivate
}// end of Class