import { NgModule } from '@angular/core';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProductDetailGuard } from './product-detail/product-detail.guard';
import { ProductEditGuard } from './product-edit/product-edit.guard';
import { SharedModule } from '../shared/shared.module';
import { AuthModule } from '../auth/auth.module';
import { AuthInterceptor } from '../auth/auth-interceptor';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthGuardGuard } from '../auth/auth-guard.guard';
import { JwtModule } from '@auth0/angular-jwt';
import { checkUserAuthGuard } from '../auth/checkuser-auth.guard';


@NgModule({
  declarations: [
    ProductListComponent,
    ProductEditComponent,
    ProductDetailComponent,

  ],
  providers:[{provide:HTTP_INTERCEPTORS,useClass:AuthInterceptor,multi:true}],
  imports: [
    ReactiveFormsModule,
    SharedModule,
    AuthModule,
    JwtModule.forRoot({
    config:{tokenGetter:()=>{
      return sessionStorage.getItem('token') ? JSON.parse(sessionStorage.getItem('token')as string).token :null
    }}
  }),
    RouterModule.forChild([{path:'products',component:ProductListComponent}, 
    {path:'products/:id',canActivate:[ProductDetailGuard],component:ProductDetailComponent},
    {path:'products/:id/edit',canDeactivate:[ProductEditGuard],component:ProductEditComponent},
    {path:'products/:id/edit',canActivate:[ProductEditGuard],component:ProductEditComponent},
    {path:'products/:id/edit',canActivate:[checkUserAuthGuard],data:{userName:"shubhamdixit912@gmail.com"},component:ProductEditComponent}]),
  ]
})
export class ProductModule { }
