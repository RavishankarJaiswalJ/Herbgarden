import { Component, OnDestroy, OnInit } from '@angular/core';
import { IProduct } from '../../data/product.model';
import { ProductApiService } from '../../services/product.api.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/auth/auth.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit ,OnDestroy{
  pageTitle='Product Detail'
  product!:IProduct | undefined;
  imageWidth=150;
  imageMargin=3;
  sub$!:Subscription;
  errorMessage!:string;
  id!:number;
  userIsAuthenticated=false;


  constructor(private apiService:ProductApiService,private route:ActivatedRoute,private router:Router,private AuthService:AuthService) { }
  
  ngOnInit(): void {
    this.userIsAuthenticated=this.AuthService.getIsAuthenticated();
    const param=this.route.snapshot.paramMap.get('id');
    if(param){
      this.id=Number(param)
  
        this.getProduct(this.id);
  
    }
  }

  getProduct(id:number){
    this.sub$=this.apiService.getProduct(id).subscribe({
      next: data=>this.product=data,
      error: err=> this.errorMessage=err
    });
 
  }

  onBack(){
    
    this.router.navigate(['/products']);
  }


  OnEdit(){
    if(!isNaN(this.id))
  this.router.navigate(['products/'+this.id+'/edit']);
  }

  ngOnDestroy(): void {
    if(this.sub$)
    {
    this.sub$.unsubscribe
    }
  }

}

