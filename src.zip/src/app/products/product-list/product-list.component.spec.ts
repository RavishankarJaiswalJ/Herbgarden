import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { IProduct } from 'src/app/data/product.model';
import { ProductListComponent } from './product-list.component';

describe('ProductListComponent', () => {
  let component: ProductListComponent;
  let productData:IProduct[];
  let mockProductApiService:any;
  
  //Create the test data and mock object
  beforeEach(async () => {
    productData=[{
                
      "id":1,
      "productName":"Lavendar",
      "productCode":"HERB-LMG",
      "description":"Used in Perfumes and Soaps",
      "price":80.5,
      "releaseDate":new Date(2021,8,7),
      "imageUrl":"assets/images/lavendar.jpg",
      "starRating":1.3
     
  },
  {
            
    "id":2,
    "productName":"Lemon Grass",
    "productCode":"HERB-LMG",
    "description":"Used in Soaps and Thai cuisuines.Can be used for tea",
    "price":80.5,
    "releaseDate":new Date(2021,8,7),
    "imageUrl":"assets/images/lemonGrass.jpg",
    "starRating":2.5
  
}
]
mockProductApiService=jasmine.createSpyObj(['getProducts'])
component=new ProductListComponent(mockProductApiService);
 
});

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should retrieve all products',()=>{
    
    mockProductApiService.getProducts.and.returnValue(of(productData));

    component.ngOnInit();
    expect(component.products.length).toBe(2);
    // expect(component.products[1].productName).toBe('Lavendar')
  })
  it('should call getProducts',()=>{
    //Arrange
    mockProductApiService.getProducts.and.returnValue(of(productData));
    //Act
    component.ngOnInit();
    //Assert
    expect(mockProductApiService.getProducts).toHaveBeenCalled();
  })

})
