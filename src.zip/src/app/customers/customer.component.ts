import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { debounce, debounceTime } from 'rxjs/operators';

function emailMatcher(c:AbstractControl){
  const emailControl=c.get('email');
  const confirmEmail=c.get('confirmEmail');

  if(emailControl?.pristine || confirmEmail?.pristine){
    return null;
  }
  else if(emailControl?.value === confirmEmail?.value){
    return null;
  }
  else{
    return {match:true};
  }
}

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  pageTitle='Customer Registration';
  customerForm!: FormGroup;
  emailMessage:string='The confirmation does not match';

  private validationMessages:any ={
    require:'Please enter your email address',
    email:'Please enter a valid email address'
  }

  constructor(private fb:FormBuilder) { }

  ngOnInit(): void {
    this.customerForm=this.fb.group({
      firstName:['',[Validators.required,Validators.minLength(3)]],
      lastName: ['',[Validators.required,Validators.maxLength(30)]],
      emailGroup:this.fb.group({
      email:['',[Validators.required,Validators.email]],
      confirmEmail:['',[Validators.required]]},
      {validators:emailMatcher}),
      phone:'',
      notification:'email',
      sendCatalog:false,
      street1:"",
      street2:"",
      city:"",
      state:"",
      zip:""
    
    });
    this.customerForm.get('notification')?.valueChanges.subscribe(
      value=>this.setNotification(value)
    );
    const emailControl=this.customerForm.get('emailGroup.email');
    emailControl?.valueChanges.pipe(debounceTime(1000)).subscribe(
      value=>this.setMessage(emailControl)
    )
  }
  setMessage(c:AbstractControl):void{
    this.emailMessage='';
    if((c.touched||c.dirty)&&c.errors){
      this.emailMessage=Object.keys(c.errors).map(key=>this.validationMessages[key]).join('')
    }
  }
  setNotification(notifyVia:string){
    const phoneControl=this.customerForm.get('phone');
    if(notifyVia==='text'){
      phoneControl?.setValidators(Validators.required)
    }
    else{
      phoneControl?.clearValidators();
    }
    phoneControl?.updateValueAndValidity();
  }
  save(){
    console.log();
    console.log("Saved "+JSON.stringify(this.customerForm.value))
  }
  populateTestData():void{
    this.customerForm.patchValue({
      firstName:'Jack',
      lastName:'Reacher',
      phone:987654
      
    })
  }

}