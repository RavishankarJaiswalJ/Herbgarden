import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StarComponent } from './star/star.component';
import { ConvertToSpacesPipe } from './convert-to-spaces.pipe';
import { GalleryComponent } from './gallery/gallery.component';
import { RxjsComponent } from './rxjsdemo';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    StarComponent,
    GalleryComponent,
    RxjsComponent,
    ConvertToSpacesPipe
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports:[
    CommonModule,
    StarComponent,
    FormsModule,
    ConvertToSpacesPipe,
  ]
})
export class SharedModule { }
