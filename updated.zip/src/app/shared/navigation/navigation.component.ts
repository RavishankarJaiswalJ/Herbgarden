import { Component, OnDestroy, OnInit } from "@angular/core";
import { Subscription } from "rxjs";
import { AuthService } from "src/app/auth/auth-service";

@Component({
    selector: 'app-nav',
    templateUrl: './navigation.component.html'
  })
  
export class NavigationComponent implements OnInit, OnDestroy{
  userIsAuthenticated=false;
  private authListenerSubs$:any =Subscription;
  constructor (private authService:AuthService){}
  ngOnInit() :void {
    this.userIsAuthenticated = this.authService.getIsAuthenticated();
    this.authListenerSubs$=this.authService.getAuthStatusListener().
    subscribe(isAuthenticated => {
        this.userIsAuthenticated = isAuthenticated;
      }
    )
  }

  // ! logout
  onLogout(){
    this.authService.logout();
  }
  
  ngOnDestroy(): void {
    this.authListenerSubs$.unsubscribe();
  }
}


// export class MagazineEditGuard implements  CanActivate,CanDeactivate<unknown> {
//   userIsAuthenticated=false;
//   constructor(private router:Router,private authService:AuthService){}
//   canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
//     this.userIsAuthenticated=this.authService.getIsAuthenticated();
//     if(!this.userIsAuthenticated){
//       alert("you haven't logged in ");
//       this.router.navig